package in.aaitel.colshop;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String uname,upass;
    //DatabaseOperations op;
    Context ctx=this;
    Button btLogin;
    boolean status;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       // op=new DatabaseOperations(this);
        final EditText Uname = (EditText) findViewById(R.id.etusername);
        final EditText Password = (EditText) findViewById(R.id.etpassword);

        btLogin = (Button) findViewById(R.id.btlogin);

        final TextView tvRegister = (TextView)findViewById(R.id.tvsignup);
        final TextView tvGuestSession = (TextView)findViewById(R.id.tvguest);

        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent RegisterIntent = new Intent(MainActivity.this,RegisterActivity.class);
                MainActivity.this.startActivity(RegisterIntent);
            }
        });

        tvGuestSession.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent guestIntent = new Intent(MainActivity.this,Navigation_and_colshop.class);
                MainActivity.this.startActivity(guestIntent);
            }
        });

        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getBaseContext(),"Please Wait ...",Toast.LENGTH_LONG).show();
                uname= Uname.getText().toString();
                upass=Password.getText().toString();



                status=false;
                String method="login";
                BackgroundClass bclass=new BackgroundClass(ctx);
                bclass.execute(method,uname,upass);
                decidingToLogiN();

            }
        });
    }

    void login()
    {
        status=true;
    }
    void decidingToLogiN() {
        if (status) {
            Toast.makeText(getBaseContext(), "Successfully Logged In", Toast.LENGTH_LONG).show();

            Intent intent = new Intent(MainActivity.this, Navigation_and_colshop.class);
            startActivity(intent);

        } else {
            Toast.makeText(getBaseContext(), "Either Username Or Password is incorrect\n\nPlease try again", Toast.LENGTH_LONG).show();

        }
    }
}
