package in.aaitel.colshop;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Created by HP-Laptop on 18-03-2017.
 */

public class BackgroundClass extends AsyncTask<String,String,String> {
    Context ctx;

    BackgroundClass(Context ctx)
    {
        this.ctx=ctx;
    }
    @Override
    protected String   doInBackground(String... params) {
        String reg_url="http://www.aaitel.in/shiv/register.php";
        String log_url="http://www.aaitel.in/shiv/login.php";
        String method = params[0];
        if(method.equals("reg"))
        {
            String fname=params[1];
            String lname=params[2];
            String uname=params[3];
            String email=params[4];
            String mobile=params[5];
            String college=params[6];
            String pass=params[7];
            String conpass=params[8];


            try {
                URL url=new URL(reg_url);


                HttpURLConnection httpuc=(HttpURLConnection) url.openConnection();
                httpuc.setRequestMethod("POST");
                httpuc.setDoOutput(true);
                OutputStream os=httpuc.getOutputStream();
                BufferedWriter bf=new BufferedWriter(new OutputStreamWriter(os,"UTF-8"));
                String data= URLEncoder.encode("first_name","UTF-8")+"="+URLEncoder.encode(fname,"UTF-8")+"&"+URLEncoder.encode("last_name","UTF-8")+"="+URLEncoder.encode(lname,"UTF-8")+"&"+URLEncoder.encode("user_name","UTF-8")+"="+URLEncoder.encode(uname,"UTF-8")+"&"+URLEncoder.encode("email","UTF-8")+"="+URLEncoder.encode(email,"UTF-8")+"&"+URLEncoder.encode("mobile","UTF-8")+"="+URLEncoder.encode(mobile,"UTF-8")+"&"+URLEncoder.encode("college_name","UTF-8")+"="+URLEncoder.encode(college,"UTF-8")+"&"+URLEncoder.encode("password","UTF-8")+"="+URLEncoder.encode(pass,"UTF-8")+"&"+URLEncoder.encode("confirm_password","UTF-8")+"="+URLEncoder.encode(conpass,"UTF-8");

                bf.write(data);
                bf.flush();
                bf.close();
                os.close();
                InputStream is=httpuc.getInputStream();
                is.close();

                return "REGISTERED";
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else
            if(method.equals("login"))
            {
                String uname=params[1];
                String pass=params[2];
                try {
                    URL url=new URL(log_url);
                    HttpURLConnection httpuc=(HttpURLConnection) url.openConnection();
                    httpuc.setRequestMethod("POST");
                    httpuc.setDoOutput(true);
                    httpuc.setDoInput(true);
                    OutputStream os=httpuc.getOutputStream();
                    BufferedWriter bf=new BufferedWriter(new OutputStreamWriter(os,"UTF-8"));
                    String data= URLEncoder.encode("user_name","UTF-8")+"="+URLEncoder.encode(uname,"UTF-8")+"&"+URLEncoder.encode("user_pass","UTF-8")+"="+URLEncoder.encode(pass,"UTF-8");
                    bf.write(data);
                    bf.flush();
                    bf.close();
                    os.close();
                    InputStream is=httpuc.getInputStream();

                    BufferedReader br=new BufferedReader(new InputStreamReader(is,"iso-8859-1"));
                    String response="";
                    String line="";
                    while((line=br.readLine())!=null)
                    {
                        response+=line;
                    }
                    br.close();
                     is.close();
                    httpuc.disconnect();
                    return response;
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (ProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }

        return "Not Undergoing";
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);

    }

    @Override
    protected void onPostExecute(String result)
    {
        if(result.equals("registered"))
        {
            RegisterActivity r=new RegisterActivity();
            r.register();
        }
        else
            {
                MainActivity m=new MainActivity();
                m.login();
            }
    }



}
