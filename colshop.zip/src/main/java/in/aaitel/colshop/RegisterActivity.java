package in.aaitel.colshop;

import android.content.Context;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

//import static in.aaitel.colshop.DatabaseOperations.etEmail;

public class RegisterActivity extends AppCompatActivity {

    EditText efName ,elName, euName,eEmail,eMobile,eCollege,ePassword,eConfirmPassword;

    Button btRegister;

    String fname,lname,uname,email,mob,clg,pass,conpass;
    //Context ctg=this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        efName = (EditText) findViewById(R.id.etfirstname);
        elName = (EditText) findViewById(R.id.etlastname);
        euName = (EditText) findViewById(R.id.etusername);
        eEmail = (EditText) findViewById(R.id.etemail);
        eMobile = (EditText) findViewById(R.id.etmobile);
        // final EditText etAge = (EditText) findViewById(R.id.etyourage);
        eCollege = (EditText) findViewById(R.id.etcollegename);
        ePassword = (EditText) findViewById(R.id.etpassword);
        eConfirmPassword = (EditText) findViewById(R.id.etconfirmpassword);

        btRegister = (Button) findViewById(R.id.btsignup);

    }

    public void registration(View v)
    {
        fname=efName.getText().toString();
        lname=elName.getText().toString();
        uname=euName.getText().toString();
        email=eEmail.getText().toString();
        mob=eMobile.getText().toString();
        clg=eCollege.getText().toString();
        pass=ePassword.getText().toString();
        conpass=eConfirmPassword.getText().toString();

        String method="reg";

        BackgroundClass bclass=new BackgroundClass(this);
       bclass.execute(method,fname,lname,uname,email,mob,clg,pass,conpass);


    }

    void register()
    {
        finish();
    }




}
